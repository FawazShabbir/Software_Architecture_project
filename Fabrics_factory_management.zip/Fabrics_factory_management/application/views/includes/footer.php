 <footer class="main-footer">
    <div class="pull-right hidden-xs">
      
    </div>
    <strong>Copyright &copy; 2020 <a href="#">Fabrics Factory</a></strong> All rights
    reserved.
  </footer>