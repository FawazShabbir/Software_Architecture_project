<?php
require_once "application/core/AdminController.php";
class Dashboard extends AdminController{

    function __construct(){
        parent::__construct();
        $this->load->model("Purchasing_model","purchase"); 
		$this->load->model("Product_model","products");
						
    }
    
    function index(){
        $data["purchase"] = count($this->purchase->read());
        $data["products"] = count($this->products->read());
        $this->load->view("dashboard", $data);
    }
    
    function Logout(){
        $this->session->unset_userdata("User_ID");
        $this->session->unset_userdata("User_Firstname");
        redirect(base_url("Login"));
    }



    }

?>