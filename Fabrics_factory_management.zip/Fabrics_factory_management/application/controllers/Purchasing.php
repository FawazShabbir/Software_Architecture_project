<?php
		
		require_once "application/core/AdminController.php";
		class Purchasing extends AdminController{

			function __construct(){
				parent::__construct();
				$this->load->model("Purchasing_model","purchase"); 
				$this->load->model("Product_model","products");
				$this->load->model("Brands_model","brands");
				$this->load->model("Units_Model","units");
				$this->load->model("Supplier_model","supplier");
			}
			
			function index(){
				
				$data["purchasing"] = $this->purchase->read();
				$this->load->view("purchasing/view",$data);
			}
			
			function purchase_recieve(){
				$data['suppliers'] 	= $this->supplier->read();
				$data['products'] 	= $this->products->read();
				$data['colours'] 	= $this->products->read_colours();
				$data['brands']	= $this->brands->read();
				$data['units']	= $this->units->read();
				$data['chemicals']	= $this->products->read_chemicals();
				$this->load->view("purchasing/add",$data);
			}
			
			
			function view($PurchaseID){
			    
			    $data['purchase']=$this->purchase->getrecords($PurchaseID);
			    $this->load->view("purchasing/viewpurchases",$data);
			}
			
			function save(){
				
				$this->form_validation->set_rules("date","Date","required");
				$this->form_validation->set_rules("productID","Product","required");
				$this->form_validation->set_rules("brandID","Brand","required");
				$this->form_validation->set_rules("unitID","Unit","required");
				$this->form_validation->set_rules("quantity","Quantity","required");
				$this->form_validation->set_rules("rate","Rate","required");
				$this->form_validation->set_rules("quantity_bundle","Quantity Bundle","required");
				
				if($this->form_validation->run()==TRUE){
				
				
				$colourID = null;
				$chemicalID = null; 
				$amount = ($this->input->post("rate") * $this->input->post("quantity"));
			
				// Add Colors or Chemicals
				$category = $this->input->post("category");
				if($category  == "chemical"){
					$chemicalID = $this->input->post("chemicalID"); 
				}else if($category  == "dyes"){
					$colourID = $this->input->post("colourID");
				}

				$data=array(
					"Date"					=> 	$_POST["date"],
					"SupplierID"			=> 	$this->input->post("supplierID"),
					"ProductID"				=>	$this->input->post("productID"),
					"BrandID"				=>	$this->input->post("brandID"),
					"ColourID"				=>  $colourID,
					"ChemicalID"			=>  $chemicalID,
					"UnitID"				=>	$this->input->post("unitID"),
					"Description"			=>	$this->input->post("description"),
					"Qtyinkg"				=>	$this->input->post("quantity") * 1000,
					"Rate"					=>	$this->input->post("rate"),
					"Amount"				=>	$amount,
					"Qtyinbundle"			=>	$this->input->post("quantity_bundle"),
					"Month" 				=>	date("m"),
					"Year" 					=>	date("Y")
				);
				
				$purchaseID = $this->purchase->save($data);

				$category = strtolower($this->input->post("category"));
				
				// Adding Entry to Purchase Stock
				$stock = array(
					"PurchaseID"			=>  $purchaseID,
					"ProductID"				=>	$this->input->post("productID"),
					"ColourID"				=>  $colourID,
					"ChemicalID"			=>  $chemicalID,
					"RemainingQuantity"		=>	$this->input->post("quantity") * 1000,
					"UsedQuantity"			=>	"0",
					"TotalQuantity"			=>	$this->input->post("quantity") * 1000,
					"is_new"				=>  "1",
					"Date"					=>	$this->input->post("date"),
					"Month" 				=>	date("m"),
					"Year" 					=>	date("Y")
				);
				
				$this->purchase->save_stock($stock);
				
				$this->session->set_flashdata("success_msg", "Purchasing Added Successfully!");
				redirect(base_url("purchasing"));
				
			}
				else{
					$this->session->set_flashdata("recieve_error","0");
					$this->purchase_recieve();
				}
			}
			
			function delete($purchaseid){
		
				
					
					// Delete Stock of this Purchase
					$this->purchase->delete_random($purchaseid, "purchase_stock");
					// Deleting Purchase
					$this->purchase->delete($purchaseid);
					
					$this->session->set_flashdata("success_msg", "Purchase Removed Successfully!");
					redirect(base_url("purchasing"));
				
					
			}
			
				
			function edit($id){
				$data['suppliers'] 	= $this->supplier->read();
				$data['purchase'] 	= $this->purchase->select($id);
				$data['products'] 	= $this->products->read();
				$data['colours'] 	= $this->products->read_colours();
				$data['chemical'] 	= $this->products->read_chemicals();
				$data['brands']	= $this->brands->read();
				$data['units']	= $this->units->read();
				$this->load->view("purchasing/edit",$data);
			}

			
			function update($purchaseid){
				
				$this->form_validation->set_rules("date","Date","required");
				$this->form_validation->set_rules("unitID","Unit","required");
				$this->form_validation->set_rules("quantity","Quantity","required");
				$this->form_validation->set_rules("rate","Rate","required");
				$this->form_validation->set_rules("quantity_bundle","Quantity Bundle","required");
				
					
				if($this->form_validation->run()==TRUE){
						
				
				$colourID = null;
				$chemicalID = null; 
				
				$category = $this->input->post("category");
				// Add Colors or Chemicals
				if($category  == "chemical"){
					$chemicalID = $this->input->post("chemicalID"); 
				}else if($category  == "dyes"){
					$colourID = $this->input->post("colourID");
				}
				
				$amount = ($this->input->post("rate") * $this->input->post("quantity"));
				
				$data=array(
					"Date"					=> 	$_POST["date"],
					"SupplierID"			=> 	$this->input->post("supplierID"),
					"UnitID"				=>	$this->input->post("unitID"),
					"Description"			=>	$this->input->post("description"),
					"Qtyinkg"				=>	$this->input->post("quantity"),
					"Rate"					=>	$this->input->post("rate"),
					"Amount"				=>	$amount,
					"Qtyinbundle"			=>	$this->input->post("quantity_bundle"),
					"Month" 				=>	date("m"),
					"Year" 					=>	date("Y")
				);
				
				$quantity = $this->input->post("quantity");
				$purchase_stock = $this->purchase->purchase_stock($purchaseid);	
				$used_quantity = $purchase_stock[0]["UsedQuantity"]; 
				if($quantity < $used_quantity){
					$this->session->set_flashdata("quantity_error", "Purchase Quantity cannot be less than Sold Quantity");
					$this->edit($purchaseid);
				}
				
			}
			
		}
		

			
		
	
		
		
		
			
		}	
?>