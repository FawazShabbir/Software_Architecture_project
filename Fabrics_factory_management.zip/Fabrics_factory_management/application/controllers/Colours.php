<?php
		
		require_once "application/core/AdminController.php";
		class Colours extends AdminController{

			function __construct(){
				parent::__construct();
				$this->load->model("Colours_Model","colours"); 
			}
			
			function index(){
				$data["colours"] = $this->colours->read();
				$this->load->view("colours/view",$data);
			}
			
			function add(){
				$this->load->view("colours/add");
			}
			
			function save(){
				
				$this->form_validation->set_rules("colourname","Name","required");
				
				if($this->form_validation->run()==TRUE){
				
				$data=array(
					"ColourName"		=> 	$_POST["colourname"]
				);

				$result = $this->colours->save($data);
					
				
					if($result){
						$this->session->set_flashdata("success_msg", "Colours Added Successfully!");
						redirect(base_url("colours"));
					}	
				}
			
				else{
					$this->add();
				}
			}
		
		
			function delete($id){
			
				
					$msg = "Data Deleted Successfully!";
					$msg_type = "success_msg";
					$success=$this->colours->delete($id);
				
				                        
				$this->session->set_flashdata($msg_type, $msg);
				redirect(base_url("colours"));
		
			
				
			}
			
				
			function edit($id){
				$data['colours'] = $this->colours->select($id);
				$this->load->view("colours/edit",$data);
			}

			
			function update($id){
				
				$this->form_validation->set_rules("colourname","Name","required");
				
				if($this->form_validation->run()==TRUE){
				
				$data=array(
					"ColourName"		=> 	$_POST["colourname"]
				);
			
				$result = $this->colours->update($id,$data);
				if($result){
					$this->session->set_flashdata("success_msg", "Colours Updated Successfully!");
					redirect(base_url("colours"));
				}	
			}
			
			else{
				$this->edit($id);
			}
			
		}
		
			
	}	
?>