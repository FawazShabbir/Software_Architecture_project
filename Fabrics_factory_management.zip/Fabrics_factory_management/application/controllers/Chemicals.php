<?php
		
		require_once "application/core/AdminController.php";
		class Chemicals extends AdminController{

			function __construct(){
				parent::__construct();
				$this->load->model("Chemical_Model","chemicals"); 
			}
			
			function index(){
				$data["chemicals"] = $this->chemicals->read();
				$this->load->view("chemicals/view",$data);
			}
			
			function add(){
				$this->load->view("chemicals/add");
			}
			
			function save(){
				
				$this->form_validation->set_rules("chemicalname","Chemical Name","required");
				
				if($this->form_validation->run()==TRUE){
				
				$data=array(
					"ChemicalName"		=> 	$_POST["chemicalname"]
				);

				$result = $this->chemicals->save($data);
					
				
					if($result){
						$this->session->set_flashdata("success_msg", "Chemicals Added Successfully!");
						redirect(base_url("chemicals"));
					}	
				}
			
				else{
					$this->add();
				}
			}
		
			
			function delete($id){
			
				
					$msg = "Data Deleted Successfully!";
					$msg_type = "success_msg";
					$success = $this->chemicals->delete($id);                        
				
				                        
				$this->session->set_flashdata($msg_type, $msg);
				redirect(base_url("chemicals"));
					
			}
			
				
			function edit($id){
				$data['chemicals'] = $this->chemicals->select($id);
				$this->load->view("chemicals/edit",$data);
			}

			
			function update($id){
				
				$this->form_validation->set_rules("chemicalname","Chemical Name","required");
				
				if($this->form_validation->run()==TRUE){
				
				$data=array(
					"ChemicalName"		=> 	$_POST["chemicalname"]
				);
			
				$result = $this->chemicals->update($id,$data);
				if($result){
					$this->session->set_flashdata("success_msg", "Chemicals Updated Successfully!");
					redirect(base_url("chemicals"));
				}	
			}
			
			else{
				$this->edit($id);
			}
			
		}
		
			
	}	
?>