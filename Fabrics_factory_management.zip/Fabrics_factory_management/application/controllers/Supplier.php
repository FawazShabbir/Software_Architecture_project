<?php
		
		require_once "application/core/AdminController.php";
		class Supplier extends AdminController{

			function __construct(){
				parent::__construct();
				$this->load->model("Supplier_model","supplier"); 
			}
			
			function index(){
				$data["suppliers"] = $this->supplier->read();
				$this->load->view("suppliers/view",$data);
			}
			
			function add(){
				$this->load->view("suppliers/add");
			}
			
			function save(){
				
				$this->form_validation->set_rules("name","Name","required");
				
				if($this->form_validation->run()==TRUE){
				
				$data=array(
					"SupplierName"	=> $_POST["name"]
				);

				$result = $this->supplier->save($data);
					
				
					if($result){
						$this->session->set_flashdata("success_msg", 
						"Supplier Added Successfully!");
						redirect(base_url("supplier"));
					}	
				}
			
				else{
					$this->add();
				}
			}
		
			
			function delete($id){
			
			
				
					$msg = "Data Deleted Successfully!";
					$msg_type = "success_msg";
					$result= $this->supplier->delete($id);
				
				
				$this->session->set_flashdata($msg_type, $msg);
				redirect(base_url("supplier"));
			
			}
			
			function edit($id){
				$data['suppliers'] = $this->supplier->select($id);
				$this->load->view("suppliers/edit",$data);
				
			}
			
			function update($id){
				
				$this->form_validation->set_rules("name","Name","required");
				
				if($this->form_validation->run()==TRUE){
				
				$data=array(
					"SupplierName"	=> $_POST["name"]
				);
			
				$result = $this->supplier->update($id,$data);
				if($result){
					$this->session->set_flashdata("success_msg", "Supplier Updated Successfully!");
					redirect(base_url("supplier"));
				}	
			}
			
			else{
				$this->edit($id);
			}
			
		}
		
		
			
	}	
?>