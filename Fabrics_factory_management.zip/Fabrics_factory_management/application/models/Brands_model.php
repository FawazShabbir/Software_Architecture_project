<?php
	
	class Brands_model extends CI_MODEL{
		
		function read(){
			$result = $this->db->get("brands");
			return $result->result_array();
		}
		
		function select($id){
			$this->db->where("BrandID",$id);
			$result = $this->db->get("brands");
			return $result->result_array();
		}
	
		function save($data){
			$result = $this->db->insert("brands",$data);
			return $result;
		}
		
		function delete($id){
			$this->db->where("BrandID",$id);
			$result = $this->db->delete("brands");
			return $this->db->error();
		}
		
		function update($id,$data){
			$this->db->where("BrandID",$id);
			$result = $this->db->update("brands",$data);
			return $result;
		}
	
		
			
		
	}

?>
