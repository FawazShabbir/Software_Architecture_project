<?php 

class Purchasing_model extends CI_Model {

		function read(){
			$this->db->join("suppliers","suppliers.SupplierID = purchasing.SupplierID","left");
			$this->db->join("products","products.ProductID = purchasing.ProductID","left");
			$this->db->order_by("PurchaseID","desc");
			$result = $this->db->get("purchasing");
			return $result->result_array();
		}
		
		
		function getrecords($Purchaseid){
		    $this->db->select("*,purchasing.Date as PurchaseDate");
		    $this->db->from("purchasing");
			$this->db->join("suppliers","suppliers.SupplierID = purchasing.SupplierID","left");
			$this->db->join("chemicals","chemicals.ChemicalID=purchasing.ChemicalID","left");
		    $this->db->join("colours","colours.ColourID=purchasing.ColourID","left");
		    $this->db->join("brands","brands.BrandID=purchasing.BrandID","left");
		    $this->db->join("products","products.ProductID=purchasing.ProductID","left");
		    $this->db->join("units","units.UnitID=purchasing.UnitID","left");
			$this->db->where("PurchaseID",$Purchaseid); 
			$query=$this->db->get();
			return $query->result_array();	
		}
		
		
		function select($id){
			$this->db->where("PurchaseID",$id);
			$result = $this->db->get("purchasing");
			return $result->result_array();
		}
	
		function save($data){
			$this->db->insert("purchasing",$data);
			$result = $this->db->insert_id();
			return $result;
		}
		
		function delete($id){
			$this->db->where("PurchaseID",$id);
			$result = $this->db->delete("purchasing");
			return $result;
		}
		
		function update($id,$data){
			$this->db->where("PurchaseID",$id);
			$result = $this->db->update("purchasing",$data);
			return $result;
		}
		
		function save_purchasing_brands($data){
			$result = $this->db->insert_batch("purchasing_brands",$data);
			return $result;
		}
		
		function save_purchasing_colors($data){
			$result = $this->db->insert_batch("purchasing_colors",$data);
			return $result;
		}
		
		
		function save_purchasing_chemicals($data){
			$result = $this->db->insert_batch("purchasing_chemicals",$data);
			return $result;
		}
		
		
		
		
		/* Delete Function for All Table Deletes */
		function delete_random($purchaseID,$table_name){
			$this->db->where("PurchaseID",$purchaseID);
			$result = $this->db->delete($table_name);
			return $result;
		}
		
		
		/* Function to Get Purchase Stock */
		function purchase_stock($purchaseID){
			$this->db->where("PurchaseID",$purchaseID);
			$result = $this->db->get("purchase_stock");
			return $result->result_array();
		}
		/* Update Stock Quantity */
		function update_quantity($purchaseID,$rq,$tq){
			$this->db->set("RemainingQuantity",$rq);
			$this->db->set("TotalQuantity",$tq);
			$this->db->where("PurchaseID",$purchaseID);
			$result = $this->db->update("purchase_stock");
			return $result;
		}
		
		
		function save_stock($data){
			$result = $this->db->insert("purchase_stock",$data);
			return $result;
		}
}

?>