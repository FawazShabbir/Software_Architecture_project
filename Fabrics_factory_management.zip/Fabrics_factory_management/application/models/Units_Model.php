<?php
	
	class Units_model extends CI_MODEL{
		
		function read(){
			$result = $this->db->get("units");
			return $result->result_array();
		}
		
		function select($id){
			$this->db->where("UnitID",$id);
			$result = $this->db->get("units");
			return $result->result_array();
		}
	
		function save($data){
			$result = $this->db->insert("units",$data);
			return $result;
		}
		
		function delete($id){
			$this->db->where("UnitID",$id);
			$result = $this->db->delete("units");
			return $result;
		}
		
		function update($id,$data){
			$this->db->where("UnitID",$id);
			$result = $this->db->update("units",$data);
			return $result;
		}
		
			
			
		
	}

?>
