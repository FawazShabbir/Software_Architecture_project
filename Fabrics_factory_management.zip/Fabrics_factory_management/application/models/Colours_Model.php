<?php
	
	class Colours_model extends CI_MODEL{
		
		function read(){
			$result = $this->db->get("colours");
			return $result->result_array();
		}
		
		function select($id){
			$this->db->where("ColourID",$id);
			$result = $this->db->get("colours");
			return $result->result_array();
		}
	
		function save($data){
			$result = $this->db->insert("colours",$data);
			return $result;
		}
		
		function delete($id){
			$this->db->where("ColourID",$id);
			$this->db->delete("colours");
			return $this->db->error();
		}
		
		function update($id,$data){
			$this->db->where("ColourID",$id);
			$result = $this->db->update("colours",$data);
			return $result;
		}
		
		
			
		
	}

?>
