<?php
	
	class Labours_Model extends CI_MODEL{
		
		function read(){
			$result = $this->db->get("labour");
			return $result->result_array();
		}
		
		function select($id){
			$this->db->where("LabourID",$id);
			$result = $this->db->get("labour");
			return $result->result_array();
		}
	
		function save($data){
			$result = $this->db->insert("labour",$data);
			return $result;
		}
		
		function delete($id){
			$this->db->where("LabourID",$id);
			$result = $this->db->delete("labour");
			return $this->db->error();
		}
		
		function update($id,$data){
			$this->db->where("LabourID",$id);
			$result = $this->db->update("labour",$data);
			return $result;
		}
	
		
		
		
	}

?>
