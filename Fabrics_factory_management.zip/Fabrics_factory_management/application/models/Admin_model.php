<?php
	
	class Admin_model extends CI_MODEL{

		function signin($email){
			$this->db->where("Username",$email);
			$result = $this->db->get("users");
			return $result->result_array();
		}

	}
	
?>