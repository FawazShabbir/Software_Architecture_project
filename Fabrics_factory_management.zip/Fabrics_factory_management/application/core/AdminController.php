<?php
	
	class AdminController extends CI_CONTROLLER{
	
			public function __construct(){
				parent::__construct();
				
				$userID = $this->session->userdata("User_ID");
				if(!isset($userID)){
					redirect(base_url("login"));
				}
                
                $this->error_messages();
			}
			/* Function is created to rename the form error msgs */
			function error_messages(){
				$this->form_validation->set_message("is_unique","A User is already registered with this %s.");
				$this->form_validation->set_message("numeric","%s Only Contains numbers.");
				$this->form_validation->set_message("required","%s is required.");
				$this->form_validation->set_message("valid_email","Please enter a valid Email Address.");
            }
			
            
    }
?>